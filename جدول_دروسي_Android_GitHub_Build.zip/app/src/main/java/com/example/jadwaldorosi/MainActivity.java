package com.example.jadwaldorosi;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(23,105,170));
        w.setNavigationBarColor(Color.rgb(23,105,170));
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.rgb(244,247,251));
        view.setWebViewClient(new WebViewClient());
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        view.loadUrl("file:///android_asset/index.html");
        setContentView(view);
    }
    @Override public void onBackPressed() {
        WebView v = (WebView) findViewById(android.R.id.content).findViewById(0);
        super.onBackPressed();
    }
}
